-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2016 at 03:49 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_mahmud_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(3) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_password` varchar(32) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'Mahmudul Hasan Khan', 'cse.mahmudul@gmail.com', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'Mahmudul Hasan Khan', 'hasan417@diu.edu.bd', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `category_id` int(4) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `category_description` text,
  `ct_publication_status` tinyint(1) NOT NULL COMMENT 'ct_publication_status = 1 for category published and ct_publication_status = 0 for category unpublished',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`, `ct_publication_status`) VALUES
(1, 'Ladies_Dress', 'All kind of Ladies Dress are available here', 1),
(2, 'Toys', 'All Kinds of toys are available here', 1),
(3, 'Android Phone', '', 1),
(4, 'Ladies_Dress123', '', 0),
(5, 'Ladies_Dress12', '', 0),
(6, 'Jersey', 'All &nbsp; kinds &nbsp; of &nbsp; Jersey &nbsp; are &nbsp; available &nbsp; here &nbsp; .&nbsp;', 1),
(7, 'Shoes', 'All &nbsp; kinds &nbsp;of &nbsp; Shoes &nbsp; are &nbsp; available &nbsp; here &nbsp; .', 1),
(8, 'Bag', 'All &nbsp; Kinds &nbsp; of &nbsp;Bags &nbsp; are &nbsp; available &nbsp; here', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `customer_id` int(8) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_password` varchar(32) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `phone` varchar(7) DEFAULT NULL,
  `fax` varchar(7) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `zip_code` varchar(5) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `first_name`, `last_name`, `customer_email`, `customer_password`, `mobile`, `phone`, `fax`, `company`, `address`, `city`, `country`, `zip_code`) VALUES
(1, 'A. B. C.', 'Dany', 'cse.mahmudul@gmail.com', 'bfd59291e825b5f2bbf1eb76569f8fe7', '+8801701757766', '', '', '', 'Posta,\r\nLalbagh', 'Dhaka', 'BD', '12345'),
(2, 'asd', 'asd', 'cse.mahmudul2@gmail.com', 'bfd59291e825b5f2bbf1eb76569f8fe7', '123', '123', '123', 'asd', 'asd\r\nasd', 'asd', 'BD', '123'),
(3, 'asd', 'asd', 'cse.mahmudul@gmail2.com', '7815696ecbf1c96e6894b779456d330e', '123', '', '', '', 'asd\r\nzxc', 'asd', 'BD', '123'),
(4, 'Test   October   First', 'Last', 'test.oct12@gmail.com', 'bfd59291e825b5f2bbf1eb76569f8fe7', '+8801701757766', '', '', '', 'Post, Lalbagh', 'Dhaka', 'BD', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manufacturer`
--

CREATE TABLE IF NOT EXISTS `tbl_manufacturer` (
  `manufacturer_id` int(5) NOT NULL AUTO_INCREMENT,
  `manufacturer_name` varchar(100) NOT NULL,
  `manufacturer_description` text,
  `mn_publication_status` tinyint(1) NOT NULL COMMENT 'mn_publication_status = 1 for manufacturer published and mn_publication_status = 0 for manufacturer unpublished',
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_manufacturer`
--

INSERT INTO `tbl_manufacturer` (`manufacturer_id`, `manufacturer_name`, `manufacturer_description`, `mn_publication_status`) VALUES
(1, 'Chanel', 'Manufacturer of Ladies Dress', 1),
(2, 'LEGO', 'All kinds of LEGO products are available here', 1),
(3, 'Samsung Mobile', '', 1),
(4, 'Walton', 'Description of Walton<br>', 1),
(5, 'Chanel1', '', 0),
(6, 'Chanel12', '', 0),
(7, 'Puma', 'All &nbsp; kinds &nbsp; of &nbsp;Products &nbsp; of &nbsp; Manufacturer &nbsp; "Puma" &nbsp; is &nbsp; available &nbsp; here &nbsp; .', 1),
(8, 'MEENA   Enterprise', 'All &nbsp; kinds &nbsp; Ladies &nbsp; cloths, &nbsp; bags &nbsp; and &nbsp; shoes &nbsp; are &nbsp; available &nbsp; here.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_id` int(9) NOT NULL AUTO_INCREMENT,
  `customer_id` int(8) NOT NULL,
  `shipping_id` int(9) NOT NULL,
  `payment_id` int(3) NOT NULL,
  `order_total` double NOT NULL,
  `order_status` varchar(25) NOT NULL DEFAULT 'Pending',
  `order_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(25) NOT NULL DEFAULT 'Pending',
  `payment_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `payment_id`, `order_total`, `order_status`, `order_date_time`, `payment_status`, `payment_date_time`) VALUES
(2, 1, 9, 1, 37000, 'Pending', '2016-09-23 15:31:17', 'Pending', '2016-09-23 15:31:17'),
(3, 1, 9, 1, 6000, 'Pending', '2016-09-23 15:36:39', 'Pending', '2016-09-23 15:36:39'),
(4, 1, 9, 1, 8000, 'Pending', '2016-09-23 15:42:50', 'Pending', '2016-09-23 15:42:50'),
(5, 1, 9, 1, 8000, 'Pending', '2016-09-23 15:45:14', 'Pending', '2016-09-23 15:45:14'),
(6, 1, 9, 1, 6000, 'Delivered', '2016-09-23 15:46:41', 'Pending', '2016-09-23 15:46:41'),
(7, 1, 9, 1, 6000, 'Delivered', '2016-09-23 15:47:23', 'Pending', '2016-09-23 15:47:23'),
(8, 1, 11, 1, 16000, 'Pending', '2016-10-10 14:21:24', 'Pending', '2016-10-10 14:21:24'),
(9, 1, 12, 1, 300, 'Pending', '2016-10-11 05:23:17', 'Pending', '2016-10-11 05:23:17'),
(10, 4, 13, 1, 63500, 'Pending', '2016-10-12 13:44:50', 'Pending', '2016-10-12 13:44:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE IF NOT EXISTS `tbl_order_details` (
  `order_details_id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(9) NOT NULL,
  `product_id` int(6) NOT NULL,
  `order_price` double NOT NULL,
  `subtotal_quantity` int(4) NOT NULL,
  PRIMARY KEY (`order_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_details_id`, `order_id`, `product_id`, `order_price`, `subtotal_quantity`) VALUES
(1, 2, 4, 4800, 5),
(2, 2, 12, 13000, 1),
(3, 3, 2, 6000, 1),
(4, 4, 3, 8000, 1),
(5, 5, 3, 8000, 1),
(6, 6, 2, 6000, 1),
(7, 7, 2, 6000, 1),
(8, 8, 14, 300, 10),
(9, 8, 12, 13000, 1),
(10, 9, 14, 300, 1),
(11, 10, 25, 3600, 10),
(12, 10, 14, 300, 5),
(13, 10, 12, 13000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `payment_id` int(3) NOT NULL AUTO_INCREMENT,
  `payment_name` varchar(50) NOT NULL,
  `payment_logo_path` varchar(200) NOT NULL,
  `payment_logo` varchar(100) NOT NULL,
  `payment_description` text,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `payment_name`, `payment_logo_path`, `payment_logo`, `payment_description`) VALUES
(1, 'Cash On Delivery', 'uploads/logo/', 'cash_on_delivery.png', 'You can pay on Cash after getting the product.'),
(2, 'Paypal', 'uploads/logo/', 'paypal.png', 'You can do payment through Paypal');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `product_id` int(6) NOT NULL AUTO_INCREMENT,
  `category_id` int(4) NOT NULL,
  `manufacturer_id` int(5) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_short_description` text,
  `product_long_description` text,
  `product_price` double NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `upload_path` varchar(200) DEFAULT NULL,
  `product_image` varchar(100) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `pr_publication_status` tinyint(1) NOT NULL COMMENT 'pr_publication_status = 1 for product published and pr_publication_status = 0 for product unpublished',
  `created_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sold_quantity` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `category_id`, `manufacturer_id`, `product_name`, `product_short_description`, `product_long_description`, `product_price`, `product_quantity`, `upload_path`, `product_image`, `expiry_date`, `pr_publication_status`, `created_date_time`, `sold_quantity`) VALUES
(2, 1, 1, 'Ut tellus dolor dapibus', 'It is a white ladies dress', 'Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.', 6000, 397, 'uploads/product_images/', 'product_img_2.jpg', NULL, 1, '2016-07-18 07:01:42', 3),
(3, 1, 1, 'Cursus eleifend elit aenean aucto', NULL, NULL, 8000, 698, 'uploads/product_images/', 'product_img_3.jpg', NULL, 1, '2016-07-18 07:01:42', 2),
(4, 2, 2, 'LEGO Superheroes Attack on Avengers Tower', 'Great set! This was $60 at Target, plus tax, and it was worth it (especially since I bought it with my birthday money). I am the sort of hopeless, introverted geek who, at eighteen years old, still plays with little plastic bricks, and this set scores in all categories.', '', 4800, 999, 'uploads/product_images/', 'lego_toy_01.jpg', NULL, 1, '2016-07-19 21:08:05', 10),
(5, 2, 2, 'LEGO Star Wars Death Star 10188', 'It seems like a great piece, but every time I have it almost finished some punk kids in orange come by and smash it. It''s gettin'' old REAL fast.', 'Battle inside the Death StarTM! Recreate the action and adventure of the Star WarsTM movies with the ultimate Death Star playset! This amazingly detailed battle station features an incredible array of minifigure-scale scenes, moving parts, characters and accessories from Episodes IV and VI on its multiple decks, including the Death Star control room, rotating turbolaser turrets, hangar bay with TIE Advanced starfighter, tractor beam controls, Emperor''s throne room, detention block, firing laser cannon, Imperial conference chamber, droid maintenance facility, and the powerful Death Star superlaser...plus much more! Swing across the chasm with Luke and Leia, face danger in the crushing trash compactor, and duel with Darth Vader for the fate of the galaxy! Reenact the final duel between Luke Skywalker and Darth Vader in the Emperor''s Throne Room! Death Star measures 16 inches (41cm) tall and 16½ inches (42cm) wide! TIE Advanced measures 3½ inches (9cm) wide! Rescue Princess Leia from the detention block cell, then escape through the secret hatch to the trash compactor below!', 59700, 1000, 'uploads/product_images/', 'lego_toy_021.jpg', NULL, 1, '2016-07-19 21:13:50', 0),
(11, 1, 1, 'Eget elementum vel', 'It is a sleeveless white Ladies tops', 'Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.', 10200, 500, 'uploads/product_images/', 'product_img_1.jpg', '2021-09-30', 1, '2016-08-24 20:36:22', 0),
(12, 3, 3, 'Samsung Galaxy', 'Short Description of Samsung Galaxy<div>hguijopl;lp[kpo</div><div>ijpk[okl[opkpk</div><div>jhuhui"uihiuhui</div>', '<b><u>Long Description of Samsung Galaxy</u></b><div>jiojoijoijojojoio</div><div>okjij8u89ukiijo</div><div>ygt"ibihyihiyhu</div>', 13000, 995, 'uploads/product_images/', 'samsung-galaxy-mega-6-3-white-2.jpg', '2018-09-30', 1, '2016-08-25 05:00:49', 5),
(13, 6, 7, 'Yellow Australian Jursey', '<strong><font face="Arial, Verdana" size="2">Short Description About&nbsp;Australian&nbsp;Jersey :</font></strong><span></span><div>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</div>', '<h>Long Description About Australian Jersey<p class="para top">LOREM IPSUM&nbsp;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined</p><ul><li>Research</li><li>Design and Development</li><li>Porting and Optimization</li><li>System integration</li><li>Verification Validation and Testing</li><li>Maintenance and Support</li></ul></h>', 300, 292, 'uploads/product_images/', '35884-cricket-australia-2015-mens-official-world-cup-shirt-740.jpg', NULL, 1, '2016-09-04 17:18:47', 0),
(14, 7, 8, 'Branded Ladies'' Shoe', '<strong>Short Description About Branded Shoe :&nbsp;</strong><span>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</span>', '<h>Long Description About Branded Shoe :<p class="para top">LOREM IPSUM&nbsp;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined</p><ul><li>Research</li><li>Design and Development</li><li>Porting and Optimization</li><li>System integration</li><li>Verification Validation and Testing</li><li>Maintenance and Support</li></ul></h>', 300, 64, 'uploads/product_images/', '32.jpg', '2018-04-30', 1, '2016-09-04 17:25:54', 16),
(15, 6, 7, 'Germany   Jersey', '<strong >Short Description About Germany Jersey :&nbsp;</strong><span ></span><span >It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</span>', '<h >Long Description About Germany Jersey</h1><p class="para top" >LOREM IPSUM&nbsp;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined</p><ul ><li>Research</li><li>Design and Development</li><li>Porting and Optimization</li><li>System integration</li><li>Verification Validation and Testing</li><li>Maintenance and Support</li></ul>', 300, 200, 'uploads/product_images/', 'file_69_125.jpg', '2016-12-16', 1, '2016-10-12 12:21:08', 0),
(16, 1, 8, 'Barbie   Dress', '<strong >Short Description About Barbie Dress :&nbsp;</strong><span >It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</span>', '<h >Long Description About Barbie Dress :</h1><p class="para top" >LOREM IPSUM&nbsp;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined</p><ul ><li>Research</li><li>Design and Development</li><li>Porting and Optimization</li><li>System integration</li><li>Verification Validation and Testing</li><li>Maintenance and Support</li></ul>', 300, 595, 'uploads/product_images/', '0011518541.jpg', NULL, 1, '2016-10-12 12:41:34', 0),
(17, 8, 7, 'Branded   Bag', '<strong >Short Description About Branded Bag :&nbsp;</strong><span >It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</span>', '<h >Long Description About Branded Bag :</h1><p class="para top" >LOREM IPSUM&nbsp;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined</p><ul ><li>Research</li><li>Design and Development</li><li>Porting and Optimization</li><li>System integration</li><li>Verification Validation and Testing</li><li>Maintenance and Support</li></ul>', 300, 334, 'uploads/product_images/', 'G1082GC.jpg', '2017-10-10', 1, '2016-10-12 12:44:29', 0),
(18, 8, 8, 'Branded   Ladies   Bag', '<strong >Short Description About Banded Ladies Bag :&nbsp;</strong><span >It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</span>', '<h >Long Description About Branded Ladies Bag :</h1><p class="para top" >LOREM IPSUM&nbsp;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined</p><ul ><li>Research</li><li>Design and Development</li><li>Porting and Optimization</li><li>System integration</li><li>Verification Validation and Testing</li><li>Maintenance and Support</li></ul>', 300, 406, 'uploads/product_images/', 'ladies-handbags-1.jpg', '2017-10-25', 1, '2016-10-12 12:49:40', 0),
(19, 7, 7, 'White Keds', '<b><i><u>Short &nbsp; &nbsp;Description</u></i></b><span > &nbsp; about &nbsp; white &nbsp; Keds</span>', '<b ><i><u>Long &nbsp; Description</u></i></b><span >  nbsp; about &nbsp; white &nbsp; Keds</span><div><ul><li><font face="Arial, Verdana"><span >Soft</span></font></li><li><font face="Arial, Verdana"><span >Fast</span></font></li><li><font face="Arial, Verdana"><span >Flexible</span></font></li></ul></div>', 2000, 700, 'uploads/product_images/', 'adk.JPG', '2017-10-11', 1, '2016-10-12 12:55:25', 0),
(20, 7, 7, 'Lime Green Keds', '<b ><i><u>Short &nbsp; &nbsp;Description</u></i></b><span >&nbsp;&nbsp; about &nbsp; lime green &nbsp; Keds</span>', '<b ><i><u>Long &nbsp; Description</u></i></b><span >&nbsp nbsp; about &nbsp; white &nbsp; Keds</span><div ><ul><li><font face="Arial, Verdana">Soft</font></li><li><font face="Arial, Verdana">Fast</font></li><li><font face="Arial, Verdana">Flexible</font></li></ul></div>', 2500, 750, 'uploads/product_images/', 'puma.JPG', '2017-10-05', 1, '2016-10-12 12:58:28', 0),
(21, 1, 1, 'Aliquam erat volutpat', 'It &nbsp; is &nbsp; a &nbsp; ladies &nbsp; dress &nbsp; with &nbsp; white &nbsp; tops &nbsp; and &nbsp; yellow &nbsp; skirst', '<span >Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.</span>', 3600, 500, 'uploads/product_images/', 'product_img_4.jpg', NULL, 1, '2016-10-12 13:14:44', 0),
(22, 1, 1, 'Eget elementum vel', 'It &nbsp; is &nbsp; a &nbsp;ladies &nbsp; dress &nbsp; with &nbsp; green &nbsp; tops &nbsp; and &nbsp; flower &nbsp; printed &nbsp; trousers', '<span >Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.</span>', 10200, 700, 'uploads/product_images/', 'product_img_5.jpg', NULL, 1, '2016-10-12 13:17:51', 0),
(23, 1, 1, 'Ut tellus dolor dapibus', 'It &nbsp; is &nbsp;a &nbsp; black &nbsp;colored &nbsp; ladies &nbsp; dress', '<span >Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.</span>', 5700, 700, 'uploads/product_images/', 'product_img_6.jpg', NULL, 1, '2016-10-12 13:21:25', 0),
(24, 1, 1, 'Cursus eleifend elit aenean ', 'It &nbsp;is &nbsp;a &nbsp;ladies &nbsp; dress &nbsp;with &nbsp; white &nbsp; tops &nbsp; and &nbsp; red &nbsp; trousers', '<span >Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.</span>', 9900, 700, 'uploads/product_images/', 'product_img_7.jpg', NULL, 1, '2016-10-12 13:24:46', 0),
(25, 1, 1, 'Aliquam erat volutpat', 'It &nbsp;is &nbsp; a &nbsp; ladies &nbsp; dress &nbsp; with &nbsp; green &nbsp; tops &nbsp; and &nbsp; printed &nbsp; skirts', '<span >Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Donec sit amet eros. Lorem ipsum dolor sit amet, consecvtetuer adipiscing elit.</span>', 3600, 790, 'uploads/product_images/', 'product_img_81.jpg', '2026-12-31', 1, '2016-10-12 13:39:14', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE IF NOT EXISTS `tbl_shipping` (
  `shipping_id` int(9) NOT NULL AUTO_INCREMENT,
  `s_first_name` varchar(50) NOT NULL,
  `s_last_name` varchar(25) NOT NULL,
  `s_email` varchar(100) NOT NULL,
  `s_mobile` varchar(14) NOT NULL,
  `s_phone` varchar(7) DEFAULT NULL,
  `s_fax` varchar(7) DEFAULT NULL,
  `s_company` varchar(100) DEFAULT NULL,
  `s_address` text NOT NULL,
  `s_city` varchar(50) NOT NULL,
  `s_country` varchar(50) NOT NULL,
  `s_zip_code` varchar(5) NOT NULL,
  PRIMARY KEY (`shipping_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `s_first_name`, `s_last_name`, `s_email`, `s_mobile`, `s_phone`, `s_fax`, `s_company`, `s_address`, `s_city`, `s_country`, `s_zip_code`) VALUES
(9, 'A. B. C.', 'Dany', 'cse.mahmudul@gmail.com', '+8801701757766', '', '', '', 'Posta,\r\nLalbagh', 'Dhaka', 'BD', '12345'),
(10, 'A. B. C.', 'Dany', 'cse.mahmudul@gmail.com', '+8801701757766', '', '', '', 'Posta,\r\nLalbagh', 'Dhaka', 'BD', '12345'),
(11, 'A. B. C.', 'Dany', 'cse.mahmudul@gmail.com', '+8801701757766', '', '', '', 'Posta,\r\nLalbagh', 'Dhaka', 'BD', '12345'),
(12, 'A. B. C.', 'Dany', 'cse.mahmudul@gmail.com', '+8801701757766', '', '', '', 'Posta,\r\nLalbagh', 'Dhaka', 'BD', '12345'),
(13, 'Shipping First', 'S Last', 'test.shipping@gmail.com', '012345', '', '', '', 'Ganghi Road', 'Mumbai', 'IN', '12345');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
